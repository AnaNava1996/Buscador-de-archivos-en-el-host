from flask import Flask, render_template, request, url_for, jsonify
import glob
app = Flask(__name__)


@app.route('/')
def index():
    #lista = glob.glob("/home/**/*.*")
    #return render_template('formulario.html', list=lista)
    return render_template('formulario.html')

@app.route('/process',methods=['GET','POST'])
def process():
    path = request.form['name'] # este request (name) sale del form.js no del html
    
    if path :
        lista = glob.glob(path,recursive=True)
        print(lista)
        if(len(lista)==0):
            return jsonify({'error':'No se han encontrado coincidencias'})
        lst = list()
        for i in lista:
            lst.append("<p>"+i+"</p>")
        return jsonify({'cosa':lst})
    return jsonify({'error':'Debe hacer una búsqueda'})

@app.route('/enviando',methods=['GET','POST'])#hacer de esto un wraper
def enviar():
    pass
    '''
    poner o importar la porquería para enviar por TCP
    '''
    return 'Enviando'

@app.route('/descargando',methods=['GET','POST'])#hacer de esto un wraper
def descargar():
    print("descargando")
    '''
    poner la porquería para descargar
    '''
    return 'Descargando'

if __name__ == '__main__':
   app.run(debug = True)
   
